package com.sirsquidly.firework_table.client;

import com.sirsquidly.firework_table.FireworkTable;
import com.sirsquidly.firework_table.menu.FireworkTableMenu;
import net.minecraft.class_1661;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_465;

public final class FireworkTableScreen extends class_465<FireworkTableMenu> {
    private static final class_2960 TEXTURE = new class_2960(FireworkTable.MOD_ID, "textures/gui/firework_table.png");

    public FireworkTableScreen(FireworkTableMenu menu, class_1661 inventory, class_2561 title) {
        super(menu, inventory, title);
        field_2792 = 176;
        field_2779 = 200;
    }

    @Override protected void method_25426() {
        super.method_25426();
        method_37063(class_4185.method_46430(class_2561.method_43470("Dyes"), b -> press(-1)).method_46434(field_2776 + 32, field_2800 + 67, 40, 18).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43470("Effects"), b -> press(-2)).method_46434(field_2776 + 32, field_2800 + 87, 50, 18).method_46431());
        int[] ids = {1, 2, 3, 4, 5};
        String[] labels = {"S", "L", "★", "C", "B"};
        for (int i = 0; i < ids.length; i++) {
            int id = ids[i];
            method_37063(class_4185.method_46430(class_2561.method_43470(labels[i]), b -> press(id)).method_46434(field_2776 + 51 + (i % 4) * 16, field_2800 + 28 + (i / 4) * 16, 15, 15).method_46431());
        }
        method_37063(class_4185.method_46430(class_2561.method_43470("F"), b -> press(101)).method_46434(field_2776 + 51, field_2800 + 73, 15, 15).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43470("T"), b -> press(102)).method_46434(field_2776 + 67, field_2800 + 73, 15, 15).method_46431());
    }

    private void press(int id) { if (field_22787.field_1761 != null) field_22787.field_1761.method_2900(field_2797.field_7763, id); }

    @Override protected void method_2389(class_332 graphics, float partialTick, int mouseX, int mouseY) {
        graphics.method_25302(TEXTURE, field_2776, field_2800, 0, 0, field_2792, field_2779);
    }

    @Override protected void method_2388(class_332 graphics, int mouseX, int mouseY) {
        graphics.method_51439(field_22793, field_22785, (field_2792 - field_22793.method_27525(field_22785)) / 2, 4, 0x404040, false);
        graphics.method_51439(field_22793, field_29347, 8, field_2779 - 94, 0x404040, false);
    }
}
