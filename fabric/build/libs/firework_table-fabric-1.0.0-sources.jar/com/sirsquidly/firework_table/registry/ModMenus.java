package com.sirsquidly.firework_table.registry;

import com.sirsquidly.firework_table.FireworkTable;
import com.sirsquidly.firework_table.menu.FireworkTableMenu;
import dev.architectury.registry.menu.MenuRegistry;
import dev.architectury.registry.registries.DeferredRegister;
import dev.architectury.registry.registries.RegistrySupplier;
import net.minecraft.class_3917;
import net.minecraft.class_7924;

public final class ModMenus {
    public static final DeferredRegister<class_3917<?>> MENUS = DeferredRegister.create(FireworkTable.MOD_ID, class_7924.field_41207);
    public static final RegistrySupplier<class_3917<FireworkTableMenu>> FIREWORK_TABLE = MENUS.register("firework_table",
            () -> MenuRegistry.ofExtended(FireworkTableMenu::new));
    private ModMenus() {}
}
