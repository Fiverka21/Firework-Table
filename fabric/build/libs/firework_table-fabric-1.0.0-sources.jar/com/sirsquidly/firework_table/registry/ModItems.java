package com.sirsquidly.firework_table.registry;

import com.sirsquidly.firework_table.FireworkTable;
import dev.architectury.registry.registries.DeferredRegister;
import dev.architectury.registry.registries.RegistrySupplier;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_7924;

public final class ModItems {
    public static final DeferredRegister<class_1792> ITEMS = DeferredRegister.create(FireworkTable.MOD_ID, class_7924.field_41197);
    public static final RegistrySupplier<class_1792> FIREWORK_TABLE = ITEMS.register("firework_table", () ->
            new class_1747(ModBlocks.FIREWORK_TABLE.get(), new class_1792.class_1793()));
    private ModItems() {}
}
