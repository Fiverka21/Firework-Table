package com.sirsquidly.firework_table.registry;

import com.sirsquidly.firework_table.FireworkTable;
import com.sirsquidly.firework_table.block.FireworkTableBlock;
import dev.architectury.registry.registries.DeferredRegister;
import dev.architectury.registry.registries.RegistrySupplier;
import net.minecraft.class_2248;
import net.minecraft.class_4970;
import net.minecraft.class_7924;

public final class ModBlocks {
    public static final DeferredRegister<class_2248> BLOCKS = DeferredRegister.create(FireworkTable.MOD_ID, class_7924.field_41254);
    public static final RegistrySupplier<class_2248> FIREWORK_TABLE = BLOCKS.register("firework_table", () ->
            new FireworkTableBlock(class_4970.class_2251.method_9637().method_9632(2.5F).method_29292()));
    private ModBlocks() {}
}
