package com.sirsquidly.firework_table.block;

import com.sirsquidly.firework_table.menu.FireworkTableMenu;
import com.sirsquidly.firework_table.registry.ModMenus;
import dev.architectury.registry.menu.MenuRegistry;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3908;
import net.minecraft.class_3965;
import net.minecraft.class_4970;
import net.minecraft.class_747;

public class FireworkTableBlock extends class_2248 {
    public FireworkTableBlock(class_4970.class_2251 properties) { super(properties); }

    @Override
    public class_1269 method_9534(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
        if (!level.field_9236 && player instanceof class_3222 serverPlayer) {
            class_3908 provider = new class_747((id, inventory, menuPlayer) ->
                    new FireworkTableMenu(id, inventory, pos), class_2561.method_43471("container.firework_table.firework_table"));
            MenuRegistry.openExtendedMenu(serverPlayer, provider, buf -> buf.method_10807(pos));
        }
        return class_1269.method_29236(level.field_9236);
    }
}
