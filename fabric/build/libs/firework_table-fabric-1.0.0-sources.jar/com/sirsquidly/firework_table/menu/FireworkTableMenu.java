package com.sirsquidly.firework_table.menu;

import com.sirsquidly.firework_table.config.Config;
import com.sirsquidly.firework_table.registry.ModMenus;
import net.minecraft.class_1263;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1769;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2540;
import net.minecraft.class_3913;
import net.minecraft.class_3914;

public final class FireworkTableMenu extends class_1703 {
    public enum FireworkTab { DYES, EXPLOSION }
    public enum FireworkShape { SMALL, LARGE, STAR, CREEPER, BURST }

    public final class_1277 input = new class_1277(18) { @Override public void method_5431() { super.method_5431(); FireworkTableMenu.this.method_7609(this); } };
    public final class_1277 result = new class_1277(1);
    private final class_3914 access;
    private final class_3913 data = new class_3913() {
        private final int[] values = new int[4];
        @Override public int method_17390(int i) { return values[i]; }
        @Override public void method_17391(int i, int value) { values[i] = value; }
        @Override public int method_17389() { return values.length; }
    };

    public FireworkTableMenu(int id, class_1661 playerInventory, class_2540 buf) {
        this(id, playerInventory, buf.method_10811());
    }

    public FireworkTableMenu(int id, class_1661 playerInventory, class_2338 pos) {
        super(ModMenus.FIREWORK_TABLE.get(), id);
        this.access = class_3914.method_17392(playerInventory.field_7546.method_37908(), pos);
        method_17360(data);

        method_7621(new class_1735(input, 0, 13, 15) { @Override public boolean method_7680(class_1799 stack) { return stack.method_31574(class_1802.field_8054); } });
        for (int i = 0; i < 8; i++) addDyeSlot(i, 53 + (i % 4) * 18, 15 + (i / 4) * 18);
        for (int i = 0; i < 8; i++) addDyeSlot(8 + i, 53 + (i % 4) * 18, 63 + (i / 4) * 18);
        method_7621(new class_1735(result, 0, 142, 67) {
            @Override public boolean method_7680(class_1799 stack) { return false; }
            @Override public class_1799 method_7671(int amount) { return super.method_7671(amount); }
            @Override public void method_7667(class_1657 player, class_1799 stack) { input.method_5434(0, 1); for (int i = 1; i < 18; i++) input.method_5434(i, 1); super.method_7667(player, stack); }
        });
        addPlayerInventory(playerInventory);
        updateOutput();
    }

    private void addDyeSlot(int index, int x, int y) {
        method_7621(new class_1735(input, index + 1, x, y) {
            @Override public boolean method_7680(class_1799 stack) { return stack.method_7909() instanceof class_1769 && !isDyeSlotDisabled(field_7874); }
        });
    }

    private void addPlayerInventory(class_1661 inventory) {
        for (int row = 0; row < 3; row++) for (int column = 0; column < 9; column++) method_7621(new class_1735(inventory, column + row * 9 + 9, 8 + column * 18, 105 + row * 18));
        for (int column = 0; column < 9; column++) method_7621(new class_1735(inventory, column, 8 + column * 18, 163));
    }

    public FireworkTab currentTab() { return FireworkTab.values()[data.method_17390(0)]; }
    public FireworkShape currentShape() { return FireworkShape.values()[data.method_17390(1)]; }
    public boolean flickEnabled() { return data.method_17390(2) == 1; }
    public boolean trailEnabled() { return data.method_17390(3) == 1; }

    @Override public boolean method_7604(class_1657 player, int id) {
        if (id > 0 && id <= 5) data.method_17391(1, id - 1);
        else if (id == 101) data.method_17391(2, data.method_17390(2) == 0 ? 1 : 0);
        else if (id == 102) data.method_17391(3, data.method_17390(3) == 0 ? 1 : 0);
        else if (id == -1) data.method_17391(0, 0);
        else if (id == -2) data.method_17391(0, 1);
        else return false;
        updateOutput();
        return true;
    }

    @Override public void method_7609(class_1263 container) { super.method_7609(container); updateOutput(); }
    private void updateOutput() {
        if (!input.method_5438(0).method_31574(class_1802.field_8054)) { result.method_5447(0, class_1799.field_8037); return; }
        int[] colors = collectColors(1, 8), fades = collectColors(9, 16);
        if (colors.length == 0 || hasLockedItems()) { result.method_5447(0, class_1799.field_8037); return; }
        class_1799 output = new class_1799(class_1802.field_8450);
        class_2487 explosion = new class_2487();
        explosion.method_10567("Type", (byte) data.method_17390(1));
        explosion.method_10539("Colors", colors);
        if (fades.length > 0) explosion.method_10539("FadeColors", fades);
        explosion.method_10556("Flicker", flickEnabled());
        explosion.method_10556("Trail", trailEnabled());
        class_2487 root = new class_2487(); root.method_10566("Explosion", explosion); output.method_7980(root);
        result.method_5447(0, output);
    }
    private boolean hasLockedItems() { for (int i = 1; i <= 8; i++) if (isDyeSlotDisabled(i - 1) && !input.method_5438(i).method_7960()) return true; return false; }
    private int[] collectColors(int first, int last) { int[] colors = new int[last - first + 1]; int count = 0; for (int i = first; i <= last; i++) { class_1799 stack = input.method_5438(i); if (stack.method_7909() instanceof class_1769 dye) colors[count++] = dye.method_7802().method_7790(); } return java.util.Arrays.copyOf(colors, count); }
    public int complexity() { return Config.enableComplexityLimits ? (data.method_17390(1) != 0 ? 1 : 0) + data.method_17390(2) + data.method_17390(3) : 0; }
    public boolean isDyeSlotDisabled(int index) { return index >= 8 - complexity() && index < 8; }

    @Override public class_1799 method_7601(class_1657 player, int index) {
        class_1735 slot = field_7761.get(index); if (!slot.method_7681()) return class_1799.field_8037;
        class_1799 copy = slot.method_7677().method_7972();
        if (index == 18) return class_1799.field_8037;
        if (index < 18) { if (!method_7616(slot.method_7677(), 18, field_7761.size(), true)) return class_1799.field_8037; }
        else if (!method_7616(slot.method_7677(), 0, 17, false)) return class_1799.field_8037;
        if (slot.method_7677().method_7960()) slot.method_7673(class_1799.field_8037); else slot.method_7668();
        return copy;
    }
    @Override public boolean method_7597(class_1657 player) { return method_17695(access, player, com.sirsquidly.firework_table.registry.ModBlocks.FIREWORK_TABLE.get()); }
    @Override public void method_7595(class_1657 player) { super.method_7595(player); if (!player.method_37908().field_9236) method_7607(player, input); }
}
